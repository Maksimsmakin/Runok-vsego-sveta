# 🛍️ Dropshipping Store (React + Vercel)

Це простий дропшипінг-магазин, створений на React, з підключеним API, кошиком та оформленням замовлення. Готовий до деплою на Vercel.

## 🔗 Демо

> Після деплою Vercel: https://your-vercel-url.vercel.app

## 🚀 Функціонал

- ✅ Отримання товарів із API
- 🛒 Додавання товарів до кошика
- 💾 Збереження кошика в localStorage
- 🧾 Оформлення замовлення через форму
- 🌐 Адаптивна верстка (TailwindCSS)
- ⚙️ Готовий для деплою на Vercel

## 📁 Структура проєкту

```
src/
├── App.jsx
├── index.js
├── index.css
├── components/
│   ├── ProductList.jsx
│   ├── Cart.jsx
│   └── Checkout.jsx
vercel.json
tailwind.config.js
```

## 🧑‍💻 Як запустити локально

1. Клонувати репозиторій:
```bash
git clone https://github.com/your-username/dropship-store.git
cd dropship-store
```

2. Встановити залежності:
```bash
npm install
```

3. Запустити проект:
```bash
npm start
```

4. Зібрати продакшн-версію:
```bash
npm run build
```

## ⚙️ Деплой на Vercel

1. Завантаж код у GitHub
2. Імпортуй репозиторій у Vercel
3. Build Command: `npm run build`
4. Output Directory: `build`

## 📦 API

https://fakestoreapi.com/products

## 📌 Технології

- React
- React Router
- TailwindCSS
- Axios
- Vercel

## ✍️ Автор

- **Telegram:** @your_name
- **GitHub:** github.com/your_username
