import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ProductList({ addToCart }) {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    axios.get("https://fakestoreapi.com/products")
      .then(res => setProducts(res.data))
      .catch(console.error);
  }, []);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
      {products.map(p => (
        <div key={p.id} className="border p-4 rounded shadow">
          <img src={p.image} alt={p.title} className="h-40 object-contain mx-auto" />
          <h3 className="mt-2 font-semibold">{p.title}</h3>
          <p className="mt-1 text-green-700 text-lg font-bold">${p.price}</p>
          <button
            onClick={() => addToCart(p)}
            className="mt-2 w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700"
          >
            Додати в кошик
          </button>
        </div>
      ))}
    </div>
  );
}
