import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Checkout({ cart, clearCart }) {
  const [email, setEmail] = useState("");
  const [address, setAddress] = useState("");
  const navigate = useNavigate();

  const handleSubmit = e => {
    e.preventDefault();
    console.log("Order submitted:", { email, address, items: cart });
    alert(\`Дякуємо! Замовлення оформлено.\`);
    clearCart();
    navigate("/");
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-md mx-auto space-y-4">
      <h2 className="text-2xl font-bold">Оформлення замовлення</h2>
      <input
        type="email"
        placeholder="Email"
        className="w-full p-2 border rounded"
        value={email}
        onChange={e => setEmail(e.target.value)}
        required
      />
      <textarea
        placeholder="Адреса доставки"
        className="w-full p-2 border rounded"
        value={address}
        onChange={e => setAddress(e.target.value)}
        required
      />
      <button type="submit" className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700">
        Підтвердити замовлення
      </button>
    </form>
  );
}
