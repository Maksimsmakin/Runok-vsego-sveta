import React from "react";
import { Link } from "react-router-dom";

export default function Cart({ cart }) {
  const total = cart.reduce((sum, i) => sum + i.price, 0).toFixed(2);

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Ваш кошик</h2>
      {cart.length === 0 ? (
        <p>Кошик порожній.</p>
      ) : (
        <>
          <ul>
            {cart.map((i, idx) => (
              <li key={idx} className="py-2 border-b">
                {i.title} — ${i.price.toFixed(2)}
              </li>
            ))}
          </ul>
          <div className="text-xl font-semibold mt-4">Загальна сума: ${total}</div>
          <Link to="/checkout" className="inline-block mt-4 bg-green-600 text-white py-2 px-4 rounded">
            Оформити замовлення
          </Link>
        </>
      )}
    </div>
  );
}
